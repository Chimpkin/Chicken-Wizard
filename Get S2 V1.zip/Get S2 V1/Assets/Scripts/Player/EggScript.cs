using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EggScript : MonoBehaviour
{
    //public float eggSpeed = 10f;

    private Transform player;
    Rigidbody2D rb;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();
        StartCoroutine(DestroySelf());

    }

    void update()
    {
        /*float angle = Mathf.Atan2(rb.velocity.y, rb.velocity.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);*/
    }

    IEnumerator DestroySelf()
    {
        yield return new WaitForSeconds(4f);
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.CompareTag("Platform")) /*|| col.gameObject.CompareTag("MovingPlatform"))*/
        {
            player.position = transform.position;
            Destroy(gameObject);
        }

        else if (other.gameObject.tag == "Player" || other.gameObject.tag == "FirePoint" || other.gameObject.tag == "Collectable")
        {
            Physics2D.IgnoreCollision(other.gameObject.GetComponent<Collider2D>(), GetComponent<Collider2D>());

        }

        else
        {
            Destroy(gameObject);

        }
    }
}
