using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{

    public GameUI scrpit;
    public float moveSpeed = 10f;
    public float jumpForce = 15f;
    public int additionalJumps = 1;
    public GameUI gameUi;
    public AimScript aimScript;
    public SlowFall slowFall;

    [SerializeField] GameObject player;
    [SerializeField] LayerMask platformLayer;
    [SerializeField] Rigidbody2D rb;
    [SerializeField] Transform feet;

    private int jumpCount = 0;
    private bool isGrounded;
    private float mx;
    private float jumpCoolDown;
    public Vector2 respawnPoint;

    void Start()
    {

        respawnPoint = transform.position;
    }

    private void Update()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        float rotateY = 0f;

        if (mousePos.x < transform.position.x)
        {
            rotateY = 180f;
        }
        transform.eulerAngles = new Vector3(transform.rotation.x, rotateY, transform.rotation.z);

        mx = Input.GetAxis("Horizontal");

        if (Input.GetButtonDown("Jump"))
        {
            Jump();
        }

        CheckGrounded();

    }

    private void FixedUpdate()
    {
        rb.velocity = new Vector2(mx * moveSpeed, rb.velocity.y);
    }

    void Jump()
    {
        if (isGrounded || jumpCount < additionalJumps)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            jumpCount++;
        }

    }

    void CheckGrounded()
    {
        if (Physics2D.OverlapCircle(feet.position, 0.1f, platformLayer))
        {
            isGrounded = true;
            jumpCount = 0;
            jumpCoolDown = Time.time + 0.05f;
        }

        else if (Time.time < jumpCoolDown)
        {
            isGrounded = true;
        }

        else
        {
            isGrounded = false;
        }

    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy") || collision.gameObject.CompareTag("Trap"))
        {
            GetComponent<Rigidbody2D>().gravityScale = 5;
            aimScript.startForce = 13;

            transform.position = respawnPoint;
        }

        if (collision.gameObject.CompareTag("checkPoint"))
        {

            respawnPoint = transform.position;
        }

        if (collision.gameObject.CompareTag("Collectable"))
        {
            scrpit.timeLeft += 10;
        }
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.CompareTag("checkPoint"))
        {
            scrpit.timerIsOn = false;
            respawnPoint = transform.position;

        }
    }

        void OnTriggerExit2D(Collider2D collider)
        {
            if (collider.gameObject.CompareTag("checkPoint"))
            {
                scrpit.timerIsOn = true;
            }


        }
    }



                    
                
      


                               