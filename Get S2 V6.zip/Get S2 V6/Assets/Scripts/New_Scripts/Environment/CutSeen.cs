using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class CutSeen : MonoBehaviour
{
    public Transform pos01, pos02;
    public Transform startPos;
    public float moveSpeed;
    Vector3 nextPos;
    void Start()
    {
        nextPos = startPos.position;
    }

    IEnumerator Waiter()
    {
        yield return new WaitForSeconds(3f);
        Debug.Log("Work");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    void Update()
    {
        if (transform.position == pos01.position)
        {
            nextPos = pos02.position;
        }
        else if (transform.position == pos02.position)
        {
            nextPos = pos01.position;
        }

        transform.position = Vector3.MoveTowards(transform.position, nextPos, moveSpeed * Time.deltaTime);

    }

    void OnTriggerEnter2D(Collider2D collider)
    {

        if (collider.gameObject.CompareTag("Dir"))
        {
            StartCoroutine(Waiter());

        }

    }
}

