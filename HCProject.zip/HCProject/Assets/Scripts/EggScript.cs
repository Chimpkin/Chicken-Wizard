using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EggScript : MonoBehaviour
{
    //public float eggSpeed = 10f;

    private Transform player;
    Rigidbody2D rb;

    void Start(){
        //rb = GetComponent<Rigidbody2D>();
        //Vector2 force = transform.right * eggSpeed;
        //rb.AddForce(force, ForceMode2D.Impulse);
        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody2D>();
        
    }

    void update()
    {
        float angle = Mathf.Atan2(rb.velocity.y, rb.velocity.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.CompareTag("Platform")){
             player.position = transform.position;
            Destroy(gameObject);
        }

        else if(collision.gameObject.tag == "Player" || collision.gameObject.tag == "FirePoint")
        {
            Physics2D.IgnoreCollision(collision.gameObject.GetComponent<Collider2D>(), GetComponent<Collider2D>());
            
        }

        else
        {
            Destroy(gameObject);
            
        }
    }
}
