OTF and TTF: Enchanted Land
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net


Welcome to the Enchanted Land where fun has no age limit! This display font borrows obvious inspiration from the classic signage used by the famous west coast amusement park. There are several others floating out there but this one features a clean glyph set with many European characters
and diacritic support for extended latin. The whimsical style of the caps flow with consistency and shows up in the numbers and many other marks as well. OTF features like kerning, ordinals, fractions, ligatures, alternates, and proportional numbers and punctuation for uppercase characters are 
all included. All caps are NOT recommended. Use Enchanted Land for a children's project, book title, or anywhere you'd like a little magic.


This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

tags: book, children, kids, script, amusement, park, fun, magic, serif, magical, publishing, display, font, typeface, fancy, whimsical, fantasy, enchanting, kid, rides, vacation, characters, Disney, land, logo


visit www.sharkshock.net for more and take a bite out of BORING design!

